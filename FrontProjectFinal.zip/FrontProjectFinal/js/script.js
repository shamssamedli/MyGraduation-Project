
'use strict';

//preloader
$(document).ready(function () {
    $("#preloader").hide();
});


//small screens sidebar menu
$(document).ready(function () {
    $(window).resize(function () { 
        if (window.innerWidth > 992) {
            $("body").css("overflow-y", "unset");
            if ($("#small-screens #sidebar-btn").hasClass("collapsed")) {
                $("#small-screens #sidebar-btn").removeClass("collapsed");
                $("#small-screens #sidebar-btn").children().removeClass("w-100")
                $("#small-screens #sidebar").removeClass("visible")
            }
        }
    });
    $("#small-screens #sidebar-btn").click(function () {
        $("#small-screens #sidebar-btn").toggleClass("collapsed")
        $(this).children().toggleClass("w-100")
        $("#small-screens #sidebar").toggleClass("visible");
        if ($(this).hasClass("collapsed")) {
            $("body").css("overflow-y", "hidden")        
        }
        else{
            $("body").css("overflow-y", "unset")  
        }        
    })
});

//menu position changer
$(document).ready(function () {
    LargeScreenMenuPositionChanger();
    document.addEventListener("scroll", function () {
        LargeScreenMenuPositionChanger();
    })
    function LargeScreenMenuPositionChanger() {
        if (document.scrollingElement.scrollTop > 42) {
            $("#large-screens .menubar").css({
                "position": "fixed",
                "width": "100%",
                "top": "0",
                "z-index": "9999999",
                //  "background-color": "rgba(17, 46, 59, 0.9)"
                "background-color": "#fff"

            })
        }
        else {
            $("#large-screens .menubar").css({
                "position": "unset",
                "background-color": "unset"
            })
        }
    }
});


//login page & register page & contact page line span width changer
$(document).ready(function () {
    $("#login .sign-in-input").focus(function () {
        LoginAndRegisterSpanLineWidthChanger("login", $(this));
    })
    $("#register .sign-in-input").focus(function () {
        LoginAndRegisterSpanLineWidthChanger("register", $(this));
    })
    $("#contact .sign-in-input").focus(function () {
        LoginAndRegisterSpanLineWidthChanger("contact", $(this));
    })
    function LoginAndRegisterSpanLineWidthChanger(section, input) {
        $(`#${section} .line`).css("width", "0%")
        $(input).next().css("width", "100%")
    }
});



// Partner

$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});

// Shopping Cart/Basket

window.onload = function () {
    if (localStorage.getItem("cart") === null) {
        localStorage.setItem("cart", JSON.stringify([]));
    }
    UpdateBasketIcon();
    const productButtons = document.querySelectorAll('.addtocart');
    const basket = JSON.parse(localStorage.getItem("cart"));

    [...productButtons].forEach(pro => {
        pro.onclick = function (e) {
            e.preventDefault();
            const proId = this.parentElement.getAttribute("data-id");
            const basketElement = basket.find(el => {
                return el.id === proId;
            })
            if (basketElement === undefined) {
                basket.push({
                    id: proId,
                    count: 1,
                    name: pro.previousElementSibling.previousElementSibling.innerText,
                    image: pro.parentElement.previousElementSibling.getAttribute("src")
                })
            }
            else {
                basketElement.count++;
            }
            //update localstorage to include new product
            localStorage.setItem("basket", JSON.stringify(basket));
            UpdateBasketIcon();
        }
    })
    basket.forEach(el => {
        const tr = document.createElement('tr');
        const proImgTd = document.createElement('td');
        const proImg = document.createElement('img');
        const proNameTd = document.createElement('td');
        const proCount = document.createElement('td');
        const remove = document.createElement('td');
        const a = document.createElement('a');
        a.href = "#"
        a.classList = "remove"
        a.id = el.id
        a.innerHTML = '<i class="fas fa-trash-alt"></i>'
        remove.appendChild(a)
        proCount.innerText = el.count;
        proImg.src = el.image;
        proImgTd.appendChild(proImg);
        proNameTd.innerText = el.name;
        tr.appendChild(proImgTd);
        tr.appendChild(proNameTd);
        tr.appendChild(proCount);
        tr.appendChild(remove);
        document.querySelector('.table').lastElementChild.appendChild(tr)
    })
    let removeBtn = document.querySelectorAll(".remove")
    removeBtn.forEach(btn => {
        btn.onclick = function(e){
            e.preventDefault();
            let id = this.id;
            let newbasket = [];
            basket.forEach(element => {
                if (element.id != id) {
                    newbasket.push(element)
                }
            });
            localStorage.clear();
            localStorage.setItem("basket", JSON.stringify(newbasket));
            window.location.reload(true)
        }
    });
}



function UpdateBasketIcon() {
    const basket = JSON.parse(localStorage.getItem("basket"));
    document.querySelector('#basket-count').innerText = basket.length;
    // document.querySelector('#basket-count').innerText = basket.reduce((t, p) => t + p.count, 0);
}





